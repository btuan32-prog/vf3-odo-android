package com.vf3.ododisplay

import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private lateinit var txtOdo: TextView
    private val prefs by lazy { Prefs(this) }
    private var lastTime: Long = 0L
    private val df = DecimalFormat("000000.0")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // giữ màn hình sáng
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        txtOdo = findViewById(R.id.txtOdo)

        lastTime = System.currentTimeMillis()

        // vòng lặp demo tăng ODO (1 km mỗi 5 giây) – thay bằng dữ liệu từ OBD khi bạn thêm ObdService
        lifecycleScope.launch(Dispatchers.Main) {
            while (isActive) {
                delay(5000)
                prefs.accumulatedKm += 1.0
                render()
            }
        }
        render()
    }

    private fun render() {
        val value = prefs.odoSeedKm + prefs.accumulatedKm
        txtOdo.text = df.format(value) + " km"
    }
}