package com.vf3.ododisplay

import android.content.Context
import kotlin.math.max

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("vf3_odo", Context.MODE_PRIVATE)

    var odoSeedKm: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("odo_seed", java.lang.Double.doubleToRawLongBits(0.0)))
        set(v) { sp.edit().putLong("odo_seed", java.lang.Double.doubleToRawLongBits(max(0.0, v))).apply() }

    var accumulatedKm: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("acc_km", java.lang.Double.doubleToRawLongBits(0.0)))
        set(v) { sp.edit().putLong("acc_km", java.lang.Double.doubleToRawLongBits(max(0.0, v))).apply() }
}