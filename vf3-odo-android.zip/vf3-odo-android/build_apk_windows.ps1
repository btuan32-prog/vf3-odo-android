
# build_apk_windows.ps1
# Mục tiêu: build APK debug trên Windows mà không cần Android Studio.
# Yêu cầu: Windows 10/11, Internet, quyền chạy script: PowerShell (Admin) > Set-ExecutionPolicy Bypass -Scope Process

$ErrorActionPreference = "Stop"

# 1) Cài JDK 17 nếu thiếu (gợi ý): tải thủ công từ https://adoptium.net (Temurin 17). Kiểm tra:
try {
  $java = & java -version 2>&1
  Write-Host "Java found:`n$java"
} catch {
  Write-Warning "Java chưa cài hoặc không nằm trong PATH. Hãy cài Temurin JDK 17 rồi chạy lại script."
  exit 1
}

# 2) Tải Android cmdline-tools
$androidRoot = "$env:USERPROFILE\Android"
$toolsDir = "$androidRoot\cmdline-tools\latest"
if (!(Test-Path $toolsDir)) {
  New-Item -Force -ItemType Directory -Path $toolsDir | Out-Null
  $zipPath = "$env:TEMP\cmdline-tools.zip"
  Invoke-WebRequest -Uri "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip" -OutFile $zipPath
  Expand-Archive -Path $zipPath -DestinationPath $toolsDir -Force
}

# 3) PATH & ANDROID_HOME
$env:ANDROID_HOME = "$androidRoot"
$env:ANDROID_SDK_ROOT = "$androidRoot"
$env:PATH = "$toolsDir\bin;$androidRoot\platform-tools;$env:PATH"

# 4) Chấp nhận license & cài SDK cần thiết
yes | sdkmanager --licenses | Out-Null
sdkmanager "platforms;android-35" "platform-tools" "build-tools;35.0.0"

# 5) Tải Gradle rời (không cần Android Studio)
$gradleDir = "$env:USERPROFILE\gradle\gradle-8.7"
if (!(Test-Path $gradleDir)) {
  New-Item -Force -ItemType Directory -Path "$env:USERPROFILE\gradle" | Out-Null
  $gradleZip = "$env:TEMP\gradle-8.7-bin.zip"
  Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-8.7-bin.zip" -OutFile $gradleZip
  Expand-Archive -Path $gradleZip -DestinationPath "$env:USERPROFILE\gradle" -Force
}
$env:PATH = "$gradleDir\bin;$env:PATH"

# 6) Build APK
Push-Location $PSScriptRoot
gradle assembleDebug --no-daemon
Pop-Location

Write-Host "`n===> APK nằm ở: app\build\outputs\apk\debug\app-debug.apk"
